# Yaji & Grill - Food Delivery System

## Android-Based Food Delivery App for Yaji and Grill Restaurant
**Location:** Katagum Local Government Area, Bauchi State, Nigeria

---

## Project Structure

```
YajiGrill_FoodDelivery/
├── backend/              # PHP REST API
│   ├── api/              # API endpoints
│   ├── config/           # Database config, Auth, Utils
│   └── uploads/          # Menu images
├── database/
│   └── yajigrill_db.sql  # MySQL database schema
└── android/
    └── customer/         # Android Customer App
        └── app/src/main/
            ├── java/     # Java source code
            └── res/      # Layouts, drawables, values
```

---

## Setup Instructions

### 1. Backend Setup (XAMPP)

1. Install XAMPP from https://www.apachefriends.org
2. Start Apache and MySQL services
3. Copy the `backend/` folder to `C:/xampp/htdocs/yajigrill/`
4. Open phpMyAdmin (http://localhost/phpmyadmin)
5. Create database `yajigrill_db`
6. Import `database/yajigrill_db.sql`
7. Update `backend/config/config.php` with your database credentials
8. Test API: http://localhost/yajigrill/api/get_categories.php

### 2. Android App Setup

1. Open `android/customer/` folder in Android Studio
2. Update `Constants.BASE_URL` in `Constants.java` with your server IP:
   ```java
   public static final String BASE_URL = "http://YOUR_IP/yajigrill/api/";
   ```
3. Add your `google-services.json` to `app/` folder (from Firebase Console)
4. Sync project with Gradle files
5. Build and run on Android device (API 24+)

### 3. Firebase Setup (Optional - for Push Notifications)

1. Go to https://console.firebase.google.com
2. Create project "YajiGrill"
3. Add Android app with package name: `com.yajigrill.customer`
4. Download `google-services.json` and place in `app/` folder
5. Copy Server Key to `backend/config/config.php`

---

## Default Login Credentials

| Role | Username/Phone | Password |
|------|---------------|----------|
| Admin | `admin` | `password` |
| Delivery Staff | `08023456789` | `password` |
| Kitchen Staff | `08045678901` | `password` |

---

## API Endpoints

### Customer APIs
- `POST customer_register.php` - Register new customer
- `POST customer_login.php` - Customer login
- `GET get_categories.php` - Get menu categories
- `GET get_menu_items.php` - Get menu items
- `POST place_order.php` - Place new order
- `GET get_orders.php` - Get customer orders
- `GET track_order.php` - Track order status
- `PUT update_profile.php` - Update profile
- `POST submit_review.php` - Submit review

### Admin APIs
- `POST admin_login.php` - Admin login
- `GET admin_get_orders.php` - Get all orders
- `PUT admin_update_order_status.php` - Update order status
- `POST admin_manage_menu.php` - Add/Edit/Delete menu items
- `GET admin_reports.php` - Generate reports

### Kitchen/Delivery APIs
- `POST kitchen_staff_login.php` - Kitchen staff login
- `GET kitchen_get_orders.php` - Get kitchen orders
- `PUT kitchen_update_status.php` - Update preparation status
- `POST delivery_staff_login.php` - Delivery staff login
- `GET delivery_get_orders.php` - Get assigned deliveries
- `PUT delivery_update_status.php` - Update delivery status

---

## Features

### Customer App
- User Registration & Login
- Browse Menu by Categories
- Add to Cart with Quantity Control
- Place Orders with Multiple Payment Options
- Real-time Order Tracking
- Order History
- Push Notifications
- Profile Management

### Admin Dashboard
- Order Management
- Menu CRUD Operations
- Customer Records
- Payment Oversight
- Sales Reports & Analytics
- Delivery Assignment

### Kitchen Module
- Real-time Order Queue
- Preparation Status Updates
- Ready for Pickup Notification

### Delivery Module
- Assigned Order View
- GPS Navigation
- Status Updates (Picked Up → In Transit → Delivered)
- Delivery Confirmation

---

## Technology Stack

| Layer | Technology |
|-------|-----------|
| Mobile App | Java, Android SDK 34 |
| Backend | PHP 8.2, MySQL 8.0 |
| Networking | Volley, Gson, REST API |
| Authentication | JWT (JSON Web Tokens) |
| Image Loading | Glide |
| Push Notifications | Firebase Cloud Messaging |
| Payment | Paystack SDK |
| Maps | Google Maps API |

---

## Academic Information

**Institution:** [Your Institution Name]
**Department:** Computer Science
**Course:** [Your Course Name]
**Supervisor:** [Supervisor Name]
**Year:** 2026

This project was developed as a case study for Yaji and Grill Restaurant, Katagum LGA, Bauchi State, Nigeria.

---

## License

This project is for academic purposes only.
