<?php
/**
 * Utility Functions
 */

class Utils {

    public static function sanitize($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
        return $data;
    }

    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL);
    }

    public static function validatePhone($phone) {
        return preg_match('/^(0|\+234)[0-9]{10}$/', $phone);
    }

    public static function generateOrderNumber() {
        return 'YG' . date('Ymd') . strtoupper(substr(uniqid(), -6));
    }

    public static function uploadImage($file, $targetDir) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
        $maxSize = 5 * 1024 * 1024; // 5MB

        if (!in_array($file['type'], $allowedTypes)) {
            return ["success" => false, "message" => "Only JPG, JPEG, PNG files allowed"];
        }

        if ($file['size'] > $maxSize) {
            return ["success" => false, "message" => "File size exceeds 5MB"];
        }

        $fileName = uniqid() . '_' . basename($file['name']);
        $targetPath = $targetDir . $fileName;

        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            return ["success" => true, "file_name" => $fileName, "path" => $targetPath];
        }

        return ["success" => false, "message" => "Failed to upload file"];
    }

    public static function sendPushNotification($fcmToken, $title, $body, $data = []) {
        $url = 'https://fcm.googleapis.com/fcm/send';
        $fields = [
            'to' => $fcmToken,
            'notification' => [
                'title' => $title,
                'body' => $body,
                'sound' => 'default'
            ],
            'data' => $data
        ];

        $headers = [
            'Authorization: key=' . FIREBASE_SERVER_KEY,
            'Content-Type: application/json'
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        curl_close($ch);

        return $result;
    }

    public static function calculateDistance($lat1, $lon1, $lat2, $lon2) {
        $R = 6371; // Earth's radius in km
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);
        $a = sin($dLat/2) * sin($dLat/2) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon/2) * sin($dLon/2);
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        return $R * $c;
    }

    public static function formatCurrency($amount) {
        return '₦' . number_format($amount, 2);
    }
}
?>
