<?php
/**
 * JWT Authentication Class
 */

require_once 'config.php';

class Auth {

    public static function generateToken($userId, $userType = 'customer') {
        $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
        $time = time();
        $payload = json_encode([
            'iss' => JWT_ISSUER,
            'aud' => JWT_AUDIENCE,
            'iat' => $time,
            'exp' => $time + JWT_EXPIRATION,
            'sub' => $userId,
            'type' => $userType
        ]);

        $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));

        $signature = hash_hmac('sha256', $base64Header . "." . $base64Payload, JWT_SECRET_KEY, true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

        return $base64Header . "." . $base64Payload . "." . $base64Signature;
    }

    public static function validateToken($token) {
        $parts = explode('.', $token);
        if (count($parts) !== 3) return false;

        $signature = hash_hmac('sha256', $parts[0] . "." . $parts[1], JWT_SECRET_KEY, true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

        if (!hash_equals($base64Signature, $parts[2])) return false;

        $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $parts[1])), true);
        if (!$payload || !isset($payload['exp']) || $payload['exp'] < time()) return false;

        return $payload;
    }

    public static function getBearerToken() {
        $headers = getallheaders();
        if (isset($headers['Authorization'])) {
            $authHeader = $headers['Authorization'];
            if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
                return $matches[1];
            }
        }
        return null;
    }

    public static function getCurrentUser() {
        $token = self::getBearerToken();
        if (!$token) return null;
        return self::validateToken($token);
    }

    public static function requireAuth() {
        $user = self::getCurrentUser();
        if (!$user) {
            http_response_code(401);
            echo json_encode(["status" => "error", "message" => "Unauthorized. Please login."]);
            exit();
        }
        return $user;
    }
}
?>
