<?php
/**
 * API Response Helper Class
 */

class Response {

    public static function success($data, $message = "Success", $code = 200) {
        http_response_code($code);
        echo json_encode([
            "status" => "success",
            "message" => $message,
            "data" => $data
        ]);
    }

    public static function error($message, $code = 400, $data = null) {
        http_response_code($code);
        echo json_encode([
            "status" => "error",
            "message" => $message,
            "data" => $data
        ]);
    }

    public static function unauthorized($message = "Unauthorized access") {
        self::error($message, 401);
    }

    public static function notFound($message = "Resource not found") {
        self::error($message, 404);
    }

    public static function validationError($errors) {
        self::error("Validation failed", 422, $errors);
    }
}
?>
