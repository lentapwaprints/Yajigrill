<?php
/**
 * Yaji and Grill - Database Configuration
 * Food Delivery System Backend
 */

// Database credentials
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'yajigrill_db');
define('DB_CHARSET', 'utf8mb4');

// API Configuration
define('API_BASE_URL', 'http://192.168.1.100/yajigrill/api/');
define('UPLOAD_PATH', '../uploads/');
define('MENU_IMAGE_PATH', '../uploads/menu_images/');

// JWT Configuration
define('JWT_SECRET_KEY', 'yaji_grill_secret_key_2026_katagum_bauchi');
define('JWT_ISSUER', 'yajigrill_api');
define('JWT_AUDIENCE', 'yajigrill_app');
define('JWT_EXPIRATION', 86400); // 24 hours

// Firebase Configuration
define('FIREBASE_SERVER_KEY', 'YOUR_FIREBASE_SERVER_KEY_HERE');

// Payment Configuration
define('PAYSTACK_SECRET_KEY', 'YOUR_PAYSTACK_SECRET_KEY');
define('PAYSTACK_PUBLIC_KEY', 'YOUR_PAYSTACK_PUBLIC_KEY');

// Email Configuration (SMTP)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'noreply@yajigrill.com');
define('SMTP_PASS', 'your_email_password');

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set timezone
date_default_timezone_set('Africa/Lagos');

// CORS Headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}
?>
