<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yaji & Grill - Admin Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
        }
        .sidebar {
            width: 260px;
            height: 100vh;
            background: #D84315;
            position: fixed;
            left: 0;
            top: 0;
            color: white;
            padding: 20px;
        }
        .sidebar h2 {
            margin-bottom: 30px;
            font-size: 24px;
        }
        .nav-item {
            padding: 12px 16px;
            margin: 4px 0;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.2);
        }
        .main-content {
            margin-left: 260px;
            padding: 30px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            color: #757575;
            font-size: 14px;
            margin-bottom: 8px;
        }
        .stat-card .value {
            font-size: 32px;
            font-weight: bold;
            color: #212121;
        }
        .orders-table {
            background: white;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #E0E0E0;
        }
        th {
            color: #757575;
            font-weight: 600;
            font-size: 14px;
        }
        .status-badge {
            padding: 4px 12px;
            border-radius: 16px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-pending { background: #FFF3E0; color: #E65100; }
        .status-confirmed { background: #E3F2FD; color: #1565C0; }
        .status-preparing { background: #F3E5F5; color: #7B1FA2; }
        .status-ready { background: #E8F5E9; color: #2E7D32; }
        .status-delivered { background: #E8F5E9; color: #2E7D32; }
        .btn-action {
            padding: 6px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            margin-right: 4px;
        }
        .btn-confirm { background: #2196F3; color: white; }
        .btn-prepare { background: #9C27B0; color: white; }
        .btn-ready { background: #4CAF50; color: white; }
        .btn-deliver { background: #FF9800; color: white; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Yaji & Grill</h2>
        <div class="nav-item active">Dashboard</div>
        <div class="nav-item">Orders</div>
        <div class="nav-item">Menu Items</div>
        <div class="nav-item">Customers</div>
        <div class="nav-item">Reports</div>
        <div class="nav-item" onclick="logout()">Logout</div>
    </div>

    <div class="main-content">
        <div class="header">
            <h1>Dashboard Overview</h1>
            <span id="adminName">Admin</span>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Today's Orders</h3>
                <div class="value" id="todayOrders">0</div>
            </div>
            <div class="stat-card">
                <h3>Today's Revenue</h3>
                <div class="value" id="todayRevenue">₦0</div>
            </div>
            <div class="stat-card">
                <h3>Pending Orders</h3>
                <div class="value" id="pendingOrders">0</div>
            </div>
            <div class="stat-card">
                <h3>Active Deliveries</h3>
                <div class="value" id="activeDeliveries">0</div>
            </div>
        </div>

        <div class="orders-table">
            <h2 style="margin-bottom: 20px;">Recent Orders</h2>
            <table>
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Customer</th>
                        <th>Items</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="ordersTableBody">
                    <!-- Orders loaded via JS -->
                </tbody>
            </table>
        </div>
    </div>

    <script>
        const token = localStorage.getItem('admin_token');
        if (!token) window.location.href = 'index.php';

        async function loadDashboard() {
            try {
                const response = await fetch('../api/admin_reports.php?type=dashboard_summary', {
                    headers: { 'Authorization': 'Bearer ' + token }
                });
                const data = await response.json();
                if (data.status === 'success') {
                    document.getElementById('todayOrders').textContent = data.data.today_orders;
                    document.getElementById('todayRevenue').textContent = '₦' + data.data.today_revenue.toLocaleString();
                    document.getElementById('pendingOrders').textContent = data.data.pending_orders;
                    document.getElementById('activeDeliveries').textContent = data.data.active_deliveries;
                }
            } catch (e) { console.error(e); }
        }

        async function loadOrders() {
            try {
                const response = await fetch('../api/admin_get_orders.php', {
                    headers: { 'Authorization': 'Bearer ' + token }
                });
                const data = await response.json();
                if (data.status === 'success') {
                    const tbody = document.getElementById('ordersTableBody');
                    tbody.innerHTML = data.data.map(order => `
                        <tr>
                            <td>${order.order_number}</td>
                            <td>${order.customer_name}</td>
                            <td>${order.items ? order.items.length : 0} items</td>
                            <td>₦${order.final_amount.toLocaleString()}</td>
                            <td><span class="status-badge status-${order.status.toLowerCase().replace(/ /g, '-')}">${order.status}</span></td>
                            <td>
                                ${getActionButtons(order.status, order.order_id)}
                            </td>
                        </tr>
                    `).join('');
                }
            } catch (e) { console.error(e); }
        }

        function getActionButtons(status, orderId) {
            const actions = {
                'Pending': `<button class="btn-action btn-confirm" onclick="updateStatus(${orderId}, 'Confirmed')">Confirm</button>`,
                'Confirmed': `<button class="btn-action btn-prepare" onclick="updateStatus(${orderId}, 'Preparing')">Prepare</button>`,
                'Preparing': `<button class="btn-action btn-ready" onclick="updateStatus(${orderId}, 'Ready')">Ready</button>`,
                'Ready': `<button class="btn-action btn-deliver" onclick="updateStatus(${orderId}, 'Out for Delivery')">Deliver</button>`,
                'Out for Delivery': `<button class="btn-action btn-confirm" onclick="updateStatus(${orderId}, 'Delivered')">Complete</button>`
            };
            return actions[status] || '';
        }

        async function updateStatus(orderId, status) {
            try {
                const response = await fetch('../api/admin_update_order_status.php', {
                    method: 'PUT',
                    headers: { 
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token 
                    },
                    body: JSON.stringify({ order_id: orderId, status })
                });
                const data = await response.json();
                if (data.status === 'success') {
                    loadOrders();
                    loadDashboard();
                }
            } catch (e) { console.error(e); }
        }

        function logout() {
            localStorage.removeItem('admin_token');
            window.location.href = 'index.php';
        }

        loadDashboard();
        loadOrders();
        setInterval(() => { loadDashboard(); loadOrders(); }, 30000);
    </script>
</body>
</html>
