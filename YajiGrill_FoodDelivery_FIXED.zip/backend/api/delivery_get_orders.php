<?php
/**
 * Delivery Staff Get Assigned Orders API
 * GET /api/delivery_get_orders.php?status=Assigned
 * Auth Required (Delivery Staff)
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';

$auth = Auth::getCurrentUser();
if (!$auth || $auth['type'] !== 'delivery') {
    Auth::requireAuth();
    exit();
}

$staff_id = $auth['sub'];
$status = isset($_GET['status']) ? $_GET['status'] : null;

$db = new Database();
$conn = $db->connect();

$sql = "SELECT o.order_id, o.order_number, o.total_amount, o.final_amount, o.status, 
               o.delivery_address, o.delivery_latitude, o.delivery_longitude, o.delivery_notes,
               o.estimated_delivery_time, o.order_date,
               u.full_name as customer_name, u.phone as customer_phone
        FROM orders o 
        JOIN users u ON o.user_id = u.user_id
        WHERE o.assigned_staff_id = ?";
$params = [$staff_id];

if ($status) {
    $sql .= " AND o.status = ?";
    $params[] = $status;
} else {
    $sql .= " AND o.status IN ('Out for Delivery', 'Ready', 'Assigned')";
}

$sql .= " ORDER BY o.order_date DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

foreach ($orders as &$order) {
    $stmt = $conn->prepare("SELECT oi.quantity, oi.unit_price, mi.item_name FROM order_items oi JOIN menu_items mi ON oi.menu_item_id = mi.item_id WHERE oi.order_id = ?");
    $stmt->execute([$order['order_id']]);
    $order['items'] = $stmt->fetchAll();
}

Response::success($orders, "Orders retrieved");
?>
