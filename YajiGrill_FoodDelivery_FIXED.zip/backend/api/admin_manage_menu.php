<?php
/**
 * Admin Manage Menu API (Add/Edit/Delete Menu Items)
 * POST /api/admin_manage_menu.php
 * Auth Required (Admin)
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';
require_once '../config/Utils.php';

$auth = Auth::getCurrentUser();
if (!$auth || $auth['type'] !== 'admin') {
    Auth::requireAuth();
    exit();
}

$action = isset($_POST['action']) ? $_POST['action'] : '';

$db = new Database();
$conn = $db->connect();

if ($action === 'add' || $action === 'edit') {
    $item_id = isset($_POST['item_id']) ? intval($_POST['item_id']) : 0;
    $item_name = Utils::sanitize($_POST['item_name']);
    $description = Utils::sanitize($_POST['description']);
    $price = floatval($_POST['price']);
    $category_id = intval($_POST['category_id']);
    $preparation_time = intval($_POST['preparation_time']);
    $availability = isset($_POST['availability']) ? 1 : 0;
    $is_featured = isset($_POST['is_featured']) ? 1 : 0;

    $image_url = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload = Utils::uploadImage($_FILES['image'], MENU_IMAGE_PATH);
        if ($upload['success']) {
            $image_url = $upload['file_name'];
        }
    }

    if ($action === 'add') {
        $stmt = $conn->prepare("INSERT INTO menu_items (item_name, description, price, category_id, image_url, preparation_time, availability, is_featured) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$item_name, $description, $price, $category_id, $image_url, $preparation_time, $availability, $is_featured])) {
            Response::success(["item_id" => $conn->lastInsertId()], "Menu item added successfully", 201);
        } else {
            Response::error("Failed to add menu item");
        }
    } else {
        $updateFields = ["item_name = ?, description = ?, price = ?, category_id = ?, preparation_time = ?, availability = ?, is_featured = ?"];
        $params = [$item_name, $description, $price, $category_id, $preparation_time, $availability, $is_featured];

        if ($image_url) {
            $updateFields[] = "image_url = ?";
            $params[] = $image_url;
        }

        $params[] = $item_id;
        $sql = "UPDATE menu_items SET " . implode(', ', $updateFields) . " WHERE item_id = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt->execute($params)) {
            Response::success(["item_id" => $item_id], "Menu item updated successfully");
        } else {
            Response::error("Failed to update menu item");
        }
    }
} elseif ($action === 'delete') {
    $item_id = intval($_POST['item_id']);
    $stmt = $conn->prepare("DELETE FROM menu_items WHERE item_id = ?");
    if ($stmt->execute([$item_id])) {
        Response::success([], "Menu item deleted successfully");
    } else {
        Response::error("Failed to delete menu item");
    }
} else {
    Response::validationError(["action" => "Invalid action. Use add, edit, or delete"]);
}
?>
