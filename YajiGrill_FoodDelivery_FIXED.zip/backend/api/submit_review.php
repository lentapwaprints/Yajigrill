<?php
/**
 * Submit Review API
 * POST /api/submit_review.php
 * Auth Required
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';

$user = Auth::requireAuth();
$user_id = $user['sub'];

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['order_id']) || !isset($data['rating'])) {
    Response::validationError(["message" => "Order ID and rating are required"]);
    exit();
}

$order_id = intval($data['order_id']);
$rating = intval($data['rating']);
$comment = isset($data['comment']) ? $data['comment'] : '';
$menu_item_id = isset($data['menu_item_id']) ? intval($data['menu_item_id']) : null;

if ($rating < 1 || $rating > 5) {
    Response::validationError(["rating" => "Rating must be between 1 and 5"]);
    exit();
}

$db = new Database();
$conn = $db->connect();

// Verify order belongs to user and is delivered
$stmt = $conn->prepare("SELECT order_id FROM orders WHERE order_id = ? AND user_id = ? AND status = 'Delivered'");
$stmt->execute([$order_id, $user_id]);
if ($stmt->rowCount() == 0) {
    Response::error("Order not found or not yet delivered", 403);
    exit();
}

// Check if already reviewed
$stmt = $conn->prepare("SELECT review_id FROM reviews WHERE order_id = ? AND user_id = ?");
$stmt->execute([$order_id, $user_id]);
if ($stmt->rowCount() > 0) {
    Response::error("You have already reviewed this order", 409);
    exit();
}

$stmt = $conn->prepare("INSERT INTO reviews (order_id, user_id, menu_item_id, rating, comment) VALUES (?, ?, ?, ?, ?)");
if ($stmt->execute([$order_id, $user_id, $menu_item_id, $rating, $comment])) {
    // Update menu item rating
    if ($menu_item_id) {
        $stmt = $conn->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as count FROM reviews WHERE menu_item_id = ?");
        $stmt->execute([$menu_item_id]);
        $rating_data = $stmt->fetch();

        $stmt = $conn->prepare("UPDATE menu_items SET rating = ?, rating_count = ? WHERE item_id = ?");
        $stmt->execute([round($rating_data['avg_rating'], 1), $rating_data['count'], $menu_item_id]);
    }

    Response::success([], "Review submitted successfully", 201);
} else {
    Response::error("Failed to submit review");
}
?>
