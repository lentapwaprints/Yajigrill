<?php
/**
 * Get Menu Items API
 * GET /api/get_menu_items.php?category_id=X&featured=1
 */

require_once '../config/Database.php';
require_once '../config/Response.php';

$db = new Database();
$conn = $db->connect();

$category_id = isset($_GET['category_id']) ? intval($_GET['category_id']) : null;
$featured = isset($_GET['featured']) ? true : false;

$sql = "SELECT m.item_id, m.item_name, m.description, m.price, m.image_url, m.preparation_time, 
               m.availability, m.is_featured, m.rating, m.rating_count,
               c.category_id, c.category_name 
        FROM menu_items m 
        JOIN categories c ON m.category_id = c.category_id 
        WHERE m.availability = 1";
$params = [];

if ($category_id) {
    $sql .= " AND m.category_id = ?";
    $params[] = $category_id;
}

if ($featured) {
    $sql .= " AND m.is_featured = 1";
}

$sql .= " ORDER BY m.is_featured DESC, m.item_name";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

foreach ($items as &$item) {
    if ($item['image_url']) {
        $item['image_url'] = API_BASE_URL . '../uploads/menu_images/' . $item['image_url'];
    }
}

Response::success($items, "Menu items retrieved successfully");
?>
