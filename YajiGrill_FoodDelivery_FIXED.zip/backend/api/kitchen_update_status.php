<?php
/**
 * Kitchen Staff Update Order Status API
 * PUT /api/kitchen_update_status.php
 * Auth Required (Kitchen Staff)
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';

$auth = Auth::getCurrentUser();
if (!$auth || $auth['type'] !== 'kitchen') {
    Auth::requireAuth();
    exit();
}

$staff_id = $auth['sub'];
$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['order_id']) || !isset($data['status'])) {
    Response::validationError(["message" => "Order ID and status are required"]);
    exit();
}

$order_id = intval($data['order_id']);
$status = $data['status'];

$valid_statuses = ['Preparing', 'Ready'];
if (!in_array($status, $valid_statuses)) {
    Response::validationError(["status" => "Kitchen can only update to Preparing or Ready"]);
    exit();
}

$db = new Database();
$conn = $db->connect();

$conn->beginTransaction();

try {
    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ? AND status IN ('Confirmed', 'Preparing')");
    $stmt->execute([$status, $order_id]);

    if ($stmt->rowCount() == 0) {
        $conn->rollBack();
        Response::error("Order not found or cannot be updated to this status", 400);
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO order_status_history (order_id, status, notes, updated_by) VALUES (?, ?, ?, ?)");
    $stmt->execute([$order_id, $status, "Updated by kitchen staff", "Kitchen Staff #$staff_id"]);

    $conn->commit();

    // Notify admin
    $stmt = $conn->prepare("SELECT order_number FROM orders WHERE order_id = ?");
    $stmt->execute([$order_id]);
    $order_data = $stmt->fetch();

    Response::success(["order_id" => $order_id, "status" => $status], "Order status updated to $status");

} catch (Exception $e) {
    $conn->rollBack();
    Response::error("Failed to update: " . $e->getMessage());
}
?>
