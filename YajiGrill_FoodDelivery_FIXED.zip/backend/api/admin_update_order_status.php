<?php
/**
 * Admin Update Order Status API
 * PUT /api/admin_update_order_status.php
 * Auth Required (Admin)
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';
require_once '../config/Utils.php';

$auth = Auth::getCurrentUser();
if (!$auth || $auth['type'] !== 'admin') {
    Auth::requireAuth();
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['order_id']) || !isset($data['status'])) {
    Response::validationError(["message" => "Order ID and status are required"]);
    exit();
}

$order_id = intval($data['order_id']);
$status = $data['status'];
$notes = isset($data['notes']) ? Utils::sanitize($data['notes']) : '';
$assigned_staff_id = isset($data['assigned_staff_id']) ? intval($data['assigned_staff_id']) : null;

$valid_statuses = ['Pending', 'Confirmed', 'Preparing', 'Ready', 'Out for Delivery', 'Delivered', 'Cancelled'];
if (!in_array($status, $valid_statuses)) {
    Response::validationError(["status" => "Invalid status value"]);
    exit();
}

$db = new Database();
$conn = $db->connect();

$conn->beginTransaction();

try {
    // Update order status
    $updateFields = ["status = ?"];
    $params = [$status];

    if ($assigned_staff_id) {
        $updateFields[] = "assigned_staff_id = ?";
        $params[] = $assigned_staff_id;
    }

    if ($status === 'Delivered') {
        $updateFields[] = "actual_delivery_time = NOW()";
    }

    $params[] = $order_id;
    $sql = "UPDATE orders SET " . implode(', ', $updateFields) . " WHERE order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);

    // Insert status history
    $stmt = $conn->prepare("INSERT INTO order_status_history (order_id, status, notes, updated_by) VALUES (?, ?, ?, ?)");
    $stmt->execute([$order_id, $status, $notes, 'Admin']);

    // If delivered, update payment status for COD
    if ($status === 'Delivered') {
        $stmt = $conn->prepare("UPDATE payments SET status = 'Completed' WHERE order_id = ? AND method = 'Cash on Delivery' AND status = 'Pending'");
        $stmt->execute([$order_id]);
    }

    $conn->commit();

    // Send notification to customer
    $stmt = $conn->prepare("SELECT u.fcm_token, o.order_number FROM orders o JOIN users u ON o.user_id = u.user_id WHERE o.order_id = ?");
    $stmt->execute([$order_id]);
    $order_data = $stmt->fetch();

    if ($order_data && $order_data['fcm_token']) {
        Utils::sendPushNotification(
            $order_data['fcm_token'],
            "Order Update",
            "Your order {$order_data['order_number']} is now: $status",
            ["order_id" => $order_id, "status" => $status]
        );
    }

    Response::success(["order_id" => $order_id, "status" => $status], "Order status updated");

} catch (Exception $e) {
    $conn->rollBack();
    Response::error("Failed to update order: " . $e->getMessage());
}
?>
