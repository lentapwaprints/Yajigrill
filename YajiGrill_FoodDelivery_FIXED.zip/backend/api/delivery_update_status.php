<?php
/**
 * Delivery Staff Update Order Status API
 * PUT /api/delivery_update_status.php
 * Auth Required (Delivery Staff)
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';
require_once '../config/Utils.php';

$auth = Auth::getCurrentUser();
if (!$auth || $auth['type'] !== 'delivery') {
    Auth::requireAuth();
    exit();
}

$staff_id = $auth['sub'];
$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['order_id']) || !isset($data['status'])) {
    Response::validationError(["message" => "Order ID and status are required"]);
    exit();
}

$order_id = intval($data['order_id']);
$status = $data['status'];
$latitude = isset($data['latitude']) ? floatval($data['latitude']) : null;
$longitude = isset($data['longitude']) ? floatval($data['longitude']) : null;

$valid_statuses = ['Picked Up', 'In Transit', 'Delivered'];
if (!in_array($status, $valid_statuses)) {
    Response::validationError(["status" => "Invalid status for delivery staff"]);
    exit();
}

$db = new Database();
$conn = $db->connect();

// Verify order belongs to this staff
$stmt = $conn->prepare("SELECT order_id FROM orders WHERE order_id = ? AND assigned_staff_id = ?");
$stmt->execute([$order_id, $staff_id]);
if ($stmt->rowCount() == 0) {
    Response::error("Order not assigned to you", 403);
    exit();
}

$conn->beginTransaction();

try {
    $updateFields = ["status = ?"];
    $params = [$status];

    if ($status === 'Delivered') {
        $updateFields[] = "actual_delivery_time = NOW()";
    }

    $params[] = $order_id;
    $sql = "UPDATE orders SET " . implode(', ', $updateFields) . " WHERE order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);

    // Update staff location
    if ($latitude && $longitude) {
        $stmt = $conn->prepare("UPDATE delivery_staff SET current_latitude = ?, current_longitude = ? WHERE staff_id = ?");
        $stmt->execute([$latitude, $longitude, $staff_id]);
    }

    // Insert status history
    $stmt = $conn->prepare("INSERT INTO order_status_history (order_id, status, notes, updated_by) VALUES (?, ?, ?, ?)");
    $stmt->execute([$order_id, $status, "Updated by delivery staff", "Delivery Staff #$staff_id"]);

    $conn->commit();

    // Notify customer
    $stmt = $conn->prepare("SELECT u.fcm_token, o.order_number FROM orders o JOIN users u ON o.user_id = u.user_id WHERE o.order_id = ?");
    $stmt->execute([$order_id]);
    $order_data = $stmt->fetch();

    if ($order_data && $order_data['fcm_token']) {
        Utils::sendPushNotification(
            $order_data['fcm_token'],
            "Delivery Update",
            "Your order {$order_data['order_number']} is now: $status",
            ["order_id" => $order_id, "status" => $status]
        );
    }

    Response::success(["order_id" => $order_id, "status" => $status], "Status updated");

} catch (Exception $e) {
    $conn->rollBack();
    Response::error("Failed to update status: " . $e->getMessage());
}
?>
