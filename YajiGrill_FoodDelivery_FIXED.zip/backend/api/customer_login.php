<?php
/**
 * Customer Login API
 * POST /api/customer_login.php
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';
require_once '../config/Utils.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['email']) || !isset($data['password'])) {
    Response::validationError(["message" => "Email and password are required"]);
    exit();
}

$email = Utils::sanitize($data['email']);
$password = $data['password'];
$fcm_token = isset($data['fcm_token']) ? $data['fcm_token'] : null;

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare("SELECT user_id, full_name, email, phone, password_hash, address FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    Response::error("Invalid email or password", 401);
    exit();
}

// Update FCM token if provided
if ($fcm_token) {
    $updateStmt = $conn->prepare("UPDATE users SET fcm_token = ? WHERE user_id = ?");
    $updateStmt->execute([$fcm_token, $user['user_id']]);
}

$token = Auth::generateToken($user['user_id'], 'customer');

Response::success([
    "user_id" => $user['user_id'],
    "full_name" => $user['full_name'],
    "email" => $user['email'],
    "phone" => $user['phone'],
    "address" => $user['address'],
    "token" => $token
], "Login successful");
?>
