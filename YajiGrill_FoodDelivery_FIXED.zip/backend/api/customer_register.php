<?php
/**
 * Customer Registration API
 * POST /api/customer_register.php
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';
require_once '../config/Utils.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['full_name']) || !isset($data['email']) || !isset($data['phone']) || !isset($data['password'])) {
    Response::validationError(["message" => "All fields are required: full_name, email, phone, password"]);
    exit();
}

$full_name = Utils::sanitize($data['full_name']);
$email = Utils::sanitize($data['email']);
$phone = Utils::sanitize($data['phone']);
$password = $data['password'];
$address = isset($data['address']) ? Utils::sanitize($data['address']) : '';

if (!Utils::validateEmail($email)) {
    Response::validationError(["email" => "Invalid email format"]);
    exit();
}

if (!Utils::validatePhone($phone)) {
    Response::validationError(["phone" => "Invalid phone number format. Use 0XXXXXXXXXX or +234XXXXXXXXXX"]);
    exit();
}

if (strlen($password) < 6) {
    Response::validationError(["password" => "Password must be at least 6 characters"]);
    exit();
}

$db = new Database();
$conn = $db->connect();

// Check if email exists
$stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
$stmt->execute([$email]);
if ($stmt->rowCount() > 0) {
    Response::error("Email already registered", 409);
    exit();
}

// Check if phone exists
$stmt = $conn->prepare("SELECT user_id FROM users WHERE phone = ?");
$stmt->execute([$phone]);
if ($stmt->rowCount() > 0) {
    Response::error("Phone number already registered", 409);
    exit();
}

$password_hash = password_hash($password, PASSWORD_BCRYPT);

$stmt = $conn->prepare("INSERT INTO users (full_name, email, phone, password_hash, address) VALUES (?, ?, ?, ?, ?)");
if ($stmt->execute([$full_name, $email, $phone, $password_hash, $address])) {
    $user_id = $conn->lastInsertId();
    $token = Auth::generateToken($user_id, 'customer');

    Response::success([
        "user_id" => $user_id,
        "full_name" => $full_name,
        "email" => $email,
        "phone" => $phone,
        "token" => $token
    ], "Registration successful", 201);
} else {
    Response::error("Registration failed. Please try again.");
}
?>
