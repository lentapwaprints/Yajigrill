<?php
/**
 * Admin Login API
 * POST /api/admin_login.php
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';
require_once '../config/Utils.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['username']) || !isset($data['password'])) {
    Response::validationError(["message" => "Username and password are required"]);
    exit();
}

$username = Utils::sanitize($data['username']);
$password = $data['password'];

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare("SELECT admin_id, username, full_name, email, role, password_hash FROM admins WHERE username = ? AND is_active = 1");
$stmt->execute([$username]);
$admin = $stmt->fetch();

if (!$admin || !password_verify($password, $admin['password_hash'])) {
    Response::error("Invalid username or password", 401);
    exit();
}

$token = Auth::generateToken($admin['admin_id'], 'admin');

Response::success([
    "admin_id" => $admin['admin_id'],
    "username" => $admin['username'],
    "full_name" => $admin['full_name'],
    "email" => $admin['email'],
    "role" => $admin['role'],
    "token" => $token
], "Login successful");
?>
