<?php
/**
 * Kitchen Staff Login API
 * POST /api/kitchen_staff_login.php
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';
require_once '../config/Utils.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['phone']) || !isset($data['password'])) {
    Response::validationError(["message" => "Phone and password are required"]);
    exit();
}

$phone = Utils::sanitize($data['phone']);
$password = $data['password'];
$fcm_token = isset($data['fcm_token']) ? $data['fcm_token'] : null;

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare("SELECT staff_id, full_name, phone, email, role, password_hash FROM kitchen_staff WHERE phone = ? AND is_active = 1");
$stmt->execute([$phone]);
$staff = $stmt->fetch();

if (!$staff || !password_verify($password, $staff['password_hash'])) {
    Response::error("Invalid phone or password", 401);
    exit();
}

if ($fcm_token) {
    $stmt = $conn->prepare("UPDATE kitchen_staff SET fcm_token = ? WHERE staff_id = ?");
    $stmt->execute([$fcm_token, $staff['staff_id']]);
}

$token = Auth::generateToken($staff['staff_id'], 'kitchen');

Response::success([
    "staff_id" => $staff['staff_id'],
    "full_name" => $staff['full_name'],
    "phone" => $staff['phone'],
    "email" => $staff['email'],
    "role" => $staff['role'],
    "token" => $token
], "Login successful");
?>
