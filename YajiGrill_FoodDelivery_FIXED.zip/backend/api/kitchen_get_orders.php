<?php
/**
 * Kitchen Staff Get Orders API
 * GET /api/kitchen_get_orders.php?status=Confirmed
 * Auth Required (Kitchen Staff)
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';

$auth = Auth::getCurrentUser();
if (!$auth || $auth['type'] !== 'kitchen') {
    Auth::requireAuth();
    exit();
}

$status = isset($_GET['status']) ? $_GET['status'] : 'Confirmed';

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare("SELECT o.order_id, o.order_number, o.status, o.total_amount, o.order_date,
                               o.estimated_delivery_time, o.delivery_notes,
                               u.full_name as customer_name, u.phone as customer_phone
                        FROM orders o 
                        JOIN users u ON o.user_id = u.user_id
                        WHERE o.status IN ('Confirmed', 'Preparing', 'Ready')
                        ORDER BY 
                            CASE o.status 
                                WHEN 'Confirmed' THEN 1 
                                WHEN 'Preparing' THEN 2 
                                WHEN 'Ready' THEN 3 
                            END, 
                            o.order_date ASC");
$stmt->execute();
$orders = $stmt->fetchAll();

foreach ($orders as &$order) {
    $stmt = $conn->prepare("SELECT oi.quantity, oi.unit_price, oi.subtotal, oi.special_instructions,
                                   mi.item_name, mi.preparation_time
                            FROM order_items oi 
                            JOIN menu_items mi ON oi.menu_item_id = mi.item_id
                            WHERE oi.order_id = ?");
    $stmt->execute([$order['order_id']]);
    $order['items'] = $stmt->fetchAll();
}

Response::success($orders, "Kitchen orders retrieved");
?>
