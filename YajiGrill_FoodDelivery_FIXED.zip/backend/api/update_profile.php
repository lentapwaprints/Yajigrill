<?php
/**
 * Update Customer Profile API
 * PUT /api/update_profile.php
 * Auth Required
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';
require_once '../config/Utils.php';

$user = Auth::requireAuth();
$user_id = $user['sub'];

$data = json_decode(file_get_contents("php://input"), true);

$db = new Database();
$conn = $db->connect();

$fields = [];
$params = [];

if (isset($data['full_name'])) {
    $fields[] = "full_name = ?";
    $params[] = Utils::sanitize($data['full_name']);
}
if (isset($data['phone'])) {
    $phone = Utils::sanitize($data['phone']);
    if (!Utils::validatePhone($phone)) {
        Response::validationError(["phone" => "Invalid phone format"]);
        exit();
    }
    $fields[] = "phone = ?";
    $params[] = $phone;
}
if (isset($data['address'])) {
    $fields[] = "address = ?";
    $params[] = Utils::sanitize($data['address']);
}
if (isset($data['latitude'])) {
    $fields[] = "latitude = ?";
    $params[] = floatval($data['latitude']);
}
if (isset($data['longitude'])) {
    $fields[] = "longitude = ?";
    $params[] = floatval($data['longitude']);
}

if (empty($fields)) {
    Response::error("No fields to update");
    exit();
}

$params[] = $user_id;
$sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE user_id = ?";
$stmt = $conn->prepare($sql);

if ($stmt->execute($params)) {
    Response::success([], "Profile updated successfully");
} else {
    Response::error("Failed to update profile");
}
?>
