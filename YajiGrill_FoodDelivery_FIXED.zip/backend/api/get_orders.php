<?php
/**
 * Get Customer Orders API
 * GET /api/get_orders.php?status=Pending&page=1
 * Auth Required
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';

$user = Auth::requireAuth();
$user_id = $user['sub'];

$status = isset($_GET['status']) ? $_GET['status'] : null;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$db = new Database();
$conn = $db->connect();

$sql = "SELECT o.order_id, o.order_number, o.total_amount, o.delivery_fee, o.final_amount, 
               o.status, o.payment_status, o.payment_method, o.delivery_address, 
               o.delivery_notes, o.estimated_delivery_time, o.order_date,
               ds.full_name as delivery_person
        FROM orders o 
        LEFT JOIN delivery_staff ds ON o.assigned_staff_id = ds.staff_id
        WHERE o.user_id = ?";
$params = [$user_id];

if ($status) {
    $sql .= " AND o.status = ?";
    $params[] = $status;
}

$sql .= " ORDER BY o.order_date DESC LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Get order items for each order
foreach ($orders as &$order) {
    $stmt = $conn->prepare("SELECT oi.item_id, oi.quantity, oi.unit_price, oi.subtotal, oi.special_instructions,
                                   mi.item_name, mi.image_url
                            FROM order_items oi 
                            JOIN menu_items mi ON oi.menu_item_id = mi.item_id
                            WHERE oi.order_id = ?");
    $stmt->execute([$order['order_id']]);
    $order['items'] = $stmt->fetchAll();

    // Get status history
    $stmt = $conn->prepare("SELECT status, notes, updated_by, created_at FROM order_status_history WHERE order_id = ? ORDER BY created_at");
    $stmt->execute([$order['order_id']]);
    $order['status_history'] = $stmt->fetchAll();
}

Response::success($orders, "Orders retrieved successfully");
?>
