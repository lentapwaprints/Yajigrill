<?php
/**
 * Admin Get All Orders API
 * GET /api/admin_get_orders.php?status=Pending&date_from=2026-01-01&date_to=2026-12-31&page=1
 * Auth Required (Admin)
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';

$auth = Auth::getCurrentUser();
if (!$auth || $auth['type'] !== 'admin') {
    Auth::requireAuth();
    exit();
}

$status = isset($_GET['status']) ? $_GET['status'] : null;
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : null;
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : null;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

$db = new Database();
$conn = $db->connect();

$sql = "SELECT o.order_id, o.order_number, o.total_amount, o.delivery_fee, o.final_amount, 
               o.status, o.payment_status, o.payment_method, o.delivery_address, 
               o.estimated_delivery_time, o.order_date, o.updated_at,
               u.full_name as customer_name, u.phone as customer_phone,
               ds.full_name as delivery_person
        FROM orders o 
        JOIN users u ON o.user_id = u.user_id
        LEFT JOIN delivery_staff ds ON o.assigned_staff_id = ds.staff_id
        WHERE 1=1";
$params = [];

if ($status) {
    $sql .= " AND o.status = ?";
    $params[] = $status;
}
if ($date_from) {
    $sql .= " AND DATE(o.order_date) >= ?";
    $params[] = $date_from;
}
if ($date_to) {
    $sql .= " AND DATE(o.order_date) <= ?";
    $params[] = $date_to;
}

$sql .= " ORDER BY o.order_date DESC LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Get items for each order
foreach ($orders as &$order) {
    $stmt = $conn->prepare("SELECT oi.quantity, oi.unit_price, oi.subtotal, mi.item_name 
                            FROM order_items oi 
                            JOIN menu_items mi ON oi.menu_item_id = mi.item_id
                            WHERE oi.order_id = ?");
    $stmt->execute([$order['order_id']]);
    $order['items'] = $stmt->fetchAll();
}

Response::success($orders, "Orders retrieved successfully");
?>
