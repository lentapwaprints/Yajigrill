<?php
/**
 * Place Order API
 * POST /api/place_order.php
 * Auth Required
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';
require_once '../config/Utils.php';

$user = Auth::requireAuth();
$user_id = $user['sub'];

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['items']) || !is_array($data['items']) || count($data['items']) == 0) {
    Response::validationError(["items" => "At least one item is required"]);
    exit();
}

if (!isset($data['delivery_address']) || empty($data['delivery_address'])) {
    Response::validationError(["delivery_address" => "Delivery address is required"]);
    exit();
}

$db = new Database();
$conn = $db->connect();

$items = $data['items'];
$delivery_address = Utils::sanitize($data['delivery_address']);
$delivery_notes = isset($data['delivery_notes']) ? Utils::sanitize($data['delivery_notes']) : '';
$payment_method = isset($data['payment_method']) ? $data['payment_method'] : 'Cash on Delivery';
$delivery_fee = 500.00;
$discount_amount = 0.00;

// Calculate total
$total_amount = 0;
$order_items_data = [];

foreach ($items as $item) {
    $stmt = $conn->prepare("SELECT item_id, price, availability FROM menu_items WHERE item_id = ?");
    $stmt->execute([$item['menu_item_id']]);
    $menu_item = $stmt->fetch();

    if (!$menu_item) {
        Response::error("Menu item not found: " . $item['menu_item_id'], 404);
        exit();
    }

    if (!$menu_item['availability']) {
        Response::error("Item not available: " . $item['menu_item_id'], 400);
        exit();
    }

    $quantity = intval($item['quantity']);
    $unit_price = floatval($menu_item['price']);
    $subtotal = $quantity * $unit_price;
    $total_amount += $subtotal;

    $order_items_data[] = [
        'menu_item_id' => $item['menu_item_id'],
        'quantity' => $quantity,
        'unit_price' => $unit_price,
        'subtotal' => $subtotal,
        'special_instructions' => isset($item['special_instructions']) ? $item['special_instructions'] : ''
    ];
}

$final_amount = $total_amount + $delivery_fee - $discount_amount;
$order_number = Utils::generateOrderNumber();

try {
    $conn->beginTransaction();

    // Insert order
    $stmt = $conn->prepare("INSERT INTO orders (user_id, order_number, total_amount, delivery_fee, discount_amount, final_amount, status, payment_status, payment_method, delivery_address, delivery_notes) VALUES (?, ?, ?, ?, ?, ?, 'Pending', 'Pending', ?, ?, ?)");
    $stmt->execute([$user_id, $order_number, $total_amount, $delivery_fee, $discount_amount, $final_amount, $payment_method, $delivery_address, $delivery_notes]);
    $order_id = $conn->lastInsertId();

    // Insert order items
    $stmt = $conn->prepare("INSERT INTO order_items (order_id, menu_item_id, quantity, unit_price, subtotal, special_instructions) VALUES (?, ?, ?, ?, ?, ?)");
    foreach ($order_items_data as $item) {
        $stmt->execute([$order_id, $item['menu_item_id'], $item['quantity'], $item['unit_price'], $item['subtotal'], $item['special_instructions']]);
    }

    // Insert initial status history
    $stmt = $conn->prepare("INSERT INTO order_status_history (order_id, status, notes) VALUES (?, 'Pending', 'Order placed successfully')");
    $stmt->execute([$order_id]);

    // Insert payment record
    $stmt = $conn->prepare("INSERT INTO payments (order_id, amount, method, status) VALUES (?, ?, ?, 'Pending')");
    $stmt->execute([$order_id, $final_amount, $payment_method]);

    $conn->commit();

    // Send notification to admin (in production, use Firebase)
    // Utils::sendPushNotification($admin_fcm, 'New Order', "Order $order_number has been placed");

    Response::success([
        "order_id" => $order_id,
        "order_number" => $order_number,
        "total_amount" => $total_amount,
        "delivery_fee" => $delivery_fee,
        "final_amount" => $final_amount,
        "status" => "Pending",
        "message" => "Order placed successfully"
    ], "Order placed successfully", 201);

} catch (Exception $e) {
    $conn->rollBack();
    Response::error("Failed to place order: " . $e->getMessage());
}
?>
