<?php
/**
 * Admin Reports API
 * GET /api/admin_reports.php?type=sales&period=daily&date_from=2026-01-01&date_to=2026-01-31
 * Auth Required (Admin)
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';

$auth = Auth::getCurrentUser();
if (!$auth || $auth['type'] !== 'admin') {
    Auth::requireAuth();
    exit();
}

$type = isset($_GET['type']) ? $_GET['type'] : 'sales';
$period = isset($_GET['period']) ? $_GET['period'] : 'daily';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-01');
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : date('Y-m-d');

$db = new Database();
$conn = $db->connect();

$report = [];

if ($type === 'sales') {
    if ($period === 'daily') {
        $stmt = $conn->prepare("SELECT DATE(order_date) as date, COUNT(*) as total_orders, SUM(final_amount) as total_revenue 
                               FROM orders WHERE status != 'Cancelled' AND DATE(order_date) BETWEEN ? AND ? 
                               GROUP BY DATE(order_date) ORDER BY date");
        $stmt->execute([$date_from, $date_to]);
        $report = $stmt->fetchAll();
    } elseif ($period === 'monthly') {
        $stmt = $conn->prepare("SELECT DATE_FORMAT(order_date, '%Y-%m') as month, COUNT(*) as total_orders, SUM(final_amount) as total_revenue 
                               FROM orders WHERE status != 'Cancelled' AND DATE(order_date) BETWEEN ? AND ? 
                               GROUP BY DATE_FORMAT(order_date, '%Y-%m') ORDER BY month");
        $stmt->execute([$date_from, $date_to]);
        $report = $stmt->fetchAll();
    }
} elseif ($type === 'popular_items') {
    $stmt = $conn->prepare("SELECT mi.item_name, SUM(oi.quantity) as total_sold, SUM(oi.subtotal) as total_revenue
                           FROM order_items oi 
                           JOIN menu_items mi ON oi.menu_item_id = mi.item_id
                           JOIN orders o ON oi.order_id = o.order_id
                           WHERE o.status != 'Cancelled' AND DATE(o.order_date) BETWEEN ? AND ?
                           GROUP BY oi.menu_item_id ORDER BY total_sold DESC LIMIT 10");
    $stmt->execute([$date_from, $date_to]);
    $report = $stmt->fetchAll();
} elseif ($type === 'order_status') {
    $stmt = $conn->prepare("SELECT status, COUNT(*) as count FROM orders WHERE DATE(order_date) BETWEEN ? AND ? GROUP BY status");
    $stmt->execute([$date_from, $date_to]);
    $report = $stmt->fetchAll();
} elseif ($type === 'dashboard_summary') {
    // Today's orders
    $stmt = $conn->prepare("SELECT COUNT(*) as today_orders, SUM(final_amount) as today_revenue FROM orders WHERE status != 'Cancelled' AND DATE(order_date) = CURDATE()");
    $stmt->execute();
    $today = $stmt->fetch();

    // Pending orders
    $stmt = $conn->prepare("SELECT COUNT(*) as pending_orders FROM orders WHERE status = 'Pending'");
    $stmt->execute();
    $pending = $stmt->fetch();

    // Total customers
    $stmt = $conn->prepare("SELECT COUNT(*) as total_customers FROM users");
    $stmt->execute();
    $customers = $stmt->fetch();

    // Active deliveries
    $stmt = $conn->prepare("SELECT COUNT(*) as active_deliveries FROM orders WHERE status IN ('Out for Delivery', 'Ready')");
    $stmt->execute();
    $deliveries = $stmt->fetch();

    $report = [
        "today_orders" => intval($today['today_orders']),
        "today_revenue" => floatval($today['today_revenue'] ?: 0),
        "pending_orders" => intval($pending['pending_orders']),
        "total_customers" => intval($customers['total_customers']),
        "active_deliveries" => intval($deliveries['active_deliveries'])
    ];
}

Response::success($report, "Report generated successfully");
?>
