<?php
/**
 * Get Customer Notifications API
 * GET /api/get_notifications.php?page=1
 * Auth Required
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';

$user = Auth::requireAuth();
$user_id = $user['sub'];

$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare("SELECT notification_id, title, message, type, is_read, reference_id, created_at 
                        FROM notifications 
                        WHERE user_id = ? 
                        ORDER BY created_at DESC 
                        LIMIT ? OFFSET ?");
$stmt->execute([$user_id, $limit, $offset]);
$notifications = $stmt->fetchAll();

// Mark as read
$stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0");
$stmt->execute([$user_id]);

Response::success($notifications, "Notifications retrieved");
?>
