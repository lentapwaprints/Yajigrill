<?php
/**
 * Track Order API
 * GET /api/track_order.php?order_id=X
 * Auth Required
 */

require_once '../config/Database.php';
require_once '../config/Response.php';
require_once '../config/Auth.php';

$user = Auth::requireAuth();
$user_id = $user['sub'];

$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

if (!$order_id) {
    Response::validationError(["order_id" => "Order ID is required"]);
    exit();
}

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare("SELECT o.order_id, o.order_number, o.status, o.payment_status, 
                               o.estimated_delivery_time, o.actual_delivery_time,
                               o.delivery_address, o.delivery_latitude, o.delivery_longitude,
                               ds.full_name as delivery_person, ds.phone as delivery_phone,
                               ds.current_latitude, ds.current_longitude
                        FROM orders o 
                        LEFT JOIN delivery_staff ds ON o.assigned_staff_id = ds.staff_id
                        WHERE o.order_id = ? AND o.user_id = ?");
$stmt->execute([$order_id, $user_id]);
$order = $stmt->fetch();

if (!$order) {
    Response::notFound("Order not found");
    exit();
}

// Get status history
$stmt = $conn->prepare("SELECT status, notes, updated_by, created_at FROM order_status_history WHERE order_id = ? ORDER BY created_at DESC");
$stmt->execute([$order_id]);
$order['status_history'] = $stmt->fetchAll();

Response::success($order, "Order tracking information retrieved");
?>
