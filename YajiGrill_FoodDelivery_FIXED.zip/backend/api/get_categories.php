<?php
/**
 * Get Menu Categories API
 * GET /api/get_categories.php
 */

require_once '../config/Database.php';
require_once '../config/Response.php';

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare("SELECT category_id, category_name, description, image_url FROM categories WHERE is_active = 1 ORDER BY display_order");
$stmt->execute();
$categories = $stmt->fetchAll();

// Prepend base URL to image paths
foreach ($categories as &$cat) {
    if ($cat['image_url']) {
        $cat['image_url'] = API_BASE_URL . '../uploads/menu_images/' . $cat['image_url'];
    }
}

Response::success($categories, "Categories retrieved successfully");
?>
