# ProGuard rules
-keep public class * {
    public protected *;
}
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
