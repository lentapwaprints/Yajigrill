package com.yajigrill.customer.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.yajigrill.customer.R;
import com.yajigrill.customer.adapters.CategoryAdapter;
import com.yajigrill.customer.adapters.MenuItemAdapter;
import com.yajigrill.customer.models.Category;
import com.yajigrill.customer.models.MenuItem;
import com.yajigrill.customer.network.ApiHelper;
import com.yajigrill.customer.utils.CartManager;
import com.yajigrill.customer.utils.Constants;
import com.yajigrill.customer.utils.SessionManager;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private BottomNavigationView bottomNavigationView;
    private RecyclerView rvCategories, rvFeaturedItems;
    private SwipeRefreshLayout swipeRefreshLayout;
    private FloatingActionButton fabCart;
    private TextView tvCartBadge;
    private ApiHelper apiHelper;
    private SessionManager sessionManager;
    private CartManager cartManager;
    private CategoryAdapter categoryAdapter;
    private MenuItemAdapter menuItemAdapter;
    private List<Category> categoryList;
    private List<MenuItem> menuItemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        apiHelper = new ApiHelper(this);
        sessionManager = new SessionManager(this);
        cartManager = new CartManager(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        rvCategories = findViewById(R.id.rvCategories);
        rvFeaturedItems = findViewById(R.id.rvFeaturedItems);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        fabCart = findViewById(R.id.fabCart);
        tvCartBadge = findViewById(R.id.tvCartBadge);

        // Setup Navigation Drawer
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        // Setup header
        View headerView = navigationView.getHeaderView(0);
        TextView tvNavName = headerView.findViewById(R.id.tvNavName);
        TextView tvNavEmail = headerView.findViewById(R.id.tvNavEmail);
        tvNavName.setText(sessionManager.getUserName());
        tvNavEmail.setText(sessionManager.getUserEmail());

        // Setup RecyclerViews
        rvCategories.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rvFeaturedItems.setLayoutManager(new GridLayoutManager(this, 2));

        categoryList = new ArrayList<>();
        menuItemList = new ArrayList<>();

        categoryAdapter = new CategoryAdapter(categoryList, category -> {
            loadMenuItems(category.getCategoryId());
        });
        rvCategories.setAdapter(categoryAdapter);

        menuItemAdapter = new MenuItemAdapter(menuItemList, item -> {
            Intent intent = new Intent(MainActivity.this, MenuDetailActivity.class);
            intent.putExtra("menu_item", item);
            startActivity(intent);
        });
        rvFeaturedItems.setAdapter(menuItemAdapter);

        // Bottom Navigation
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                loadFeaturedItems();
                return true;
            } else if (id == R.id.nav_orders) {
                startActivity(new Intent(MainActivity.this, OrderHistoryActivity.class));
                return true;
            } else if (id == R.id.nav_profile) {
                startActivity(new Intent(MainActivity.this, ProfileActivity.class));
                return true;
            }
            return false;
        });

        // Cart FAB
        fabCart.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, CartActivity.class));
        });

        // Swipe Refresh
        swipeRefreshLayout.setOnRefreshListener(() -> {
            loadCategories();
            loadFeaturedItems();
        });

        loadCategories();
        loadFeaturedItems();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCartBadge();
    }

    private void updateCartBadge() {
        int count = cartManager.getCartCount();
        if (count > 0) {
            tvCartBadge.setVisibility(View.VISIBLE);
            tvCartBadge.setText(String.valueOf(count));
        } else {
            tvCartBadge.setVisibility(View.GONE);
        }
    }

    private void loadCategories() {
        apiHelper.get(Constants.API_GET_CATEGORIES, new ApiHelper.ApiCallback() {
            @Override
            public void onSuccess(String response) {
                try {
                    JSONObject json = new JSONObject(response);
                    if (json.getString("status").equals("success")) {
                        JSONArray data = json.getJSONArray("data");
                        categoryList.clear();
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject obj = data.getJSONObject(i);
                            Category cat = new Category();
                            cat.setCategoryId(obj.getInt("category_id"));
                            cat.setCategoryName(obj.getString("category_name"));
                            cat.setDescription(obj.getString("description"));
                            cat.setImageUrl(obj.getString("image_url"));
                            categoryList.add(cat);
                        }
                        categoryAdapter.notifyDataSetChanged();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                swipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onError(String error) {
                swipeRefreshLayout.setRefreshing(false);
                Toast.makeText(MainActivity.this, "Error loading categories", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadFeaturedItems() {
        apiHelper.get(Constants.API_GET_MENU_ITEMS + "?featured=1", new ApiHelper.ApiCallback() {
            @Override
            public void onSuccess(String response) {
                try {
                    JSONObject json = new JSONObject(response);
                    if (json.getString("status").equals("success")) {
                        JSONArray data = json.getJSONArray("data");
                        menuItemList.clear();
                        for (int i = 0; i < data.length(); i++) {
                            menuItemList.add(parseMenuItem(data.getJSONObject(i)));
                        }
                        menuItemAdapter.notifyDataSetChanged();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String error) {
                Toast.makeText(MainActivity.this, "Error loading menu", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadMenuItems(int categoryId) {
        apiHelper.get(Constants.API_GET_MENU_ITEMS + "?category_id=" + categoryId, new ApiHelper.ApiCallback() {
            @Override
            public void onSuccess(String response) {
                try {
                    JSONObject json = new JSONObject(response);
                    if (json.getString("status").equals("success")) {
                        JSONArray data = json.getJSONArray("data");
                        menuItemList.clear();
                        for (int i = 0; i < data.length(); i++) {
                            menuItemList.add(parseMenuItem(data.getJSONObject(i)));
                        }
                        menuItemAdapter.notifyDataSetChanged();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String error) {
                Toast.makeText(MainActivity.this, "Error loading items", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private MenuItem parseMenuItem(JSONObject obj) throws JSONException {
        MenuItem item = new MenuItem();
        item.setItemId(obj.getInt("item_id"));
        item.setItemName(obj.getString("item_name"));
        item.setDescription(obj.getString("description"));
        item.setPrice(obj.getDouble("price"));
        item.setImageUrl(obj.getString("image_url"));
        item.setPreparationTime(obj.getInt("preparation_time"));
        item.setAvailability(obj.getInt("availability") == 1);
        item.setFeatured(obj.getInt("is_featured") == 1);
        item.setRating(obj.getDouble("rating"));
        item.setRatingCount(obj.getInt("rating_count"));
        item.setCategoryId(obj.getInt("category_id"));
        item.setCategoryName(obj.getString("category_name"));
        return item;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_drawer_home) {
            loadFeaturedItems();
        } else if (id == R.id.nav_drawer_orders) {
            startActivity(new Intent(this, OrderHistoryActivity.class));
        } else if (id == R.id.nav_drawer_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
        } else if (id == R.id.nav_drawer_logout) {
            sessionManager.clearSession();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
