package com.yajigrill.customer.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.yajigrill.customer.R;
import com.yajigrill.customer.adapters.StatusHistoryAdapter;
import com.yajigrill.customer.network.ApiHelper;
import com.yajigrill.customer.utils.Constants;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class OrderTrackingActivity extends AppCompatActivity {

    private TextView tvOrderNumber, tvStatus, tvEstimatedTime, tvDeliveryPerson;
    private RecyclerView rvStatusHistory;
    private ApiHelper apiHelper;
    private int orderId;
    private Handler refreshHandler;
    private Runnable refreshRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_tracking);

        apiHelper = new ApiHelper(this);
        orderId = getIntent().getIntExtra("order_id", 0);

        tvOrderNumber = findViewById(R.id.tvOrderNumber);
        tvStatus = findViewById(R.id.tvStatus);
        tvEstimatedTime = findViewById(R.id.tvEstimatedTime);
        tvDeliveryPerson = findViewById(R.id.tvDeliveryPerson);
        rvStatusHistory = findViewById(R.id.rvStatusHistory);
        rvStatusHistory.setLayoutManager(new LinearLayoutManager(this));

        loadTrackingInfo();

        // Auto-refresh every 30 seconds
        refreshHandler = new Handler(Looper.getMainLooper());
        refreshRunnable = this::loadTrackingInfo;
        refreshHandler.postDelayed(refreshRunnable, 30000);
    }

    private void loadTrackingInfo() {
        apiHelper.get(Constants.API_TRACK_ORDER + "?order_id=" + orderId, new ApiHelper.ApiCallback() {
            @Override
            public void onSuccess(String response) {
                try {
                    JSONObject json = new JSONObject(response);
                    if (json.getString("status").equals("success")) {
                        JSONObject data = json.getJSONObject("data");
                        tvOrderNumber.setText("Order #" + data.getString("order_number"));
                        tvStatus.setText("Status: " + data.getString("status"));
                        tvEstimatedTime.setText("Est. Delivery: " + (data.isNull("estimated_delivery_time") ? "Calculating..." : data.getString("estimated_delivery_time")));
                        tvDeliveryPerson.setText("Delivery: " + (data.isNull("delivery_person") ? "Not assigned yet" : data.getString("delivery_person")));

                        JSONArray history = data.getJSONArray("status_history");
                        rvStatusHistory.setAdapter(new StatusHistoryAdapter(history));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String error) {
                Toast.makeText(OrderTrackingActivity.this, "Error loading tracking info", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (refreshHandler != null) {
            refreshHandler.removeCallbacks(refreshRunnable);
        }
    }
}
