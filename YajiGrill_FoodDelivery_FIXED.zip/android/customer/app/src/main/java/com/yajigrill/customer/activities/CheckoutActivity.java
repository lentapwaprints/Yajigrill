package com.yajigrill.customer.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.yajigrill.customer.R;
import com.yajigrill.customer.models.MenuItem;
import com.yajigrill.customer.network.ApiHelper;
import com.yajigrill.customer.utils.CartManager;
import com.yajigrill.customer.utils.Constants;
import com.yajigrill.customer.utils.SessionManager;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.List;

public class CheckoutActivity extends AppCompatActivity {

    private TextView tvOrderSummary, tvTotalAmount;
    private EditText etDeliveryAddress, etDeliveryNotes;
    private RadioGroup rgPaymentMethod;
    private Button btnPlaceOrder;
    private ApiHelper apiHelper;
    private CartManager cartManager;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        apiHelper = new ApiHelper(this);
        cartManager = new CartManager(this);
        sessionManager = new SessionManager(this);

        tvOrderSummary = findViewById(R.id.tvOrderSummary);
        tvTotalAmount = findViewById(R.id.tvTotalAmount);
        etDeliveryAddress = findViewById(R.id.etDeliveryAddress);
        etDeliveryNotes = findViewById(R.id.etDeliveryNotes);
        rgPaymentMethod = findViewById(R.id.rgPaymentMethod);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);

        // Pre-fill address
        etDeliveryAddress.setText(sessionManager.getUserAddress());

        List<MenuItem> cartItems = cartManager.getCartItems();
        StringBuilder summary = new StringBuilder();
        double total = Constants.DELIVERY_FEE;
        for (MenuItem item : cartItems) {
            summary.append(item.getQuantityInCart()).append(" x ").append(item.getItemName()).append("
");
            total += item.getPrice() * item.getQuantityInCart();
        }
        tvOrderSummary.setText(summary.toString());
        tvTotalAmount.setText("Total: " + Constants.formatCurrency(total));

        btnPlaceOrder.setOnClickListener(v -> placeOrder());
    }

    private void placeOrder() {
        String address = etDeliveryAddress.getText().toString().trim();
        String notes = etDeliveryNotes.getText().toString().trim();

        if (address.isEmpty()) {
            etDeliveryAddress.setError("Delivery address required");
            return;
        }

        int selectedPaymentId = rgPaymentMethod.getCheckedRadioButtonId();
        RadioButton selectedPayment = findViewById(selectedPaymentId);
        String paymentMethod = selectedPayment != null ? selectedPayment.getText().toString() : "Cash on Delivery";

        try {
            JSONObject params = new JSONObject();
            params.put("delivery_address", address);
            params.put("delivery_notes", notes);
            params.put("payment_method", paymentMethod);

            JSONArray items = new JSONArray();
            for (MenuItem item : cartManager.getCartItems()) {
                JSONObject itemObj = new JSONObject();
                itemObj.put("menu_item_id", item.getItemId());
                itemObj.put("quantity", item.getQuantityInCart());
                items.put(itemObj);
            }
            params.put("items", items);

            apiHelper.post(Constants.API_PLACE_ORDER, params, new ApiHelper.ApiCallback() {
                @Override
                public void onSuccess(String response) {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getString("status").equals("success")) {
                            JSONObject data = json.getJSONObject("data");
                            cartManager.clearCart();
                            Toast.makeText(CheckoutActivity.this, "Order placed! Order #: " + data.getString("order_number"), Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(CheckoutActivity.this, OrderTrackingActivity.class);
                            intent.putExtra("order_id", data.getInt("order_id"));
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(CheckoutActivity.this, json.getString("message"), Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onError(String error) {
                    Toast.makeText(CheckoutActivity.this, "Error: " + error, Toast.LENGTH_LONG).show();
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
