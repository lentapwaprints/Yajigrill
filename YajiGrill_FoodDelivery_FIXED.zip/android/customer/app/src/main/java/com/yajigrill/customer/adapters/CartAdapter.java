package com.yajigrill.customer.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.yajigrill.customer.R;
import com.yajigrill.customer.models.MenuItem;
import com.yajigrill.customer.utils.Constants;
import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {

    private List<MenuItem> items;
    private CartListener listener;

    public interface CartListener {
        void onQuantityChanged(int itemId, int quantity);
        void onItemRemoved(int itemId);
    }

    public CartAdapter(List<MenuItem> items, CartListener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cart, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MenuItem item = items.get(position);
        holder.tvItemName.setText(item.getItemName());
        holder.tvItemPrice.setText(Constants.formatCurrency(item.getPrice()));
        holder.tvQuantity.setText(String.valueOf(item.getQuantityInCart()));
        holder.tvSubtotal.setText(Constants.formatCurrency(item.getPrice() * item.getQuantityInCart()));

        Glide.with(holder.itemView.getContext())
            .load(item.getImageUrl())
            .placeholder(R.drawable.ic_food_placeholder)
            .into(holder.ivItemImage);

        holder.btnDecrease.setOnClickListener(v -> {
            if (item.getQuantityInCart() > 1) {
                listener.onQuantityChanged(item.getItemId(), item.getQuantityInCart() - 1);
            }
        });

        holder.btnIncrease.setOnClickListener(v -> {
            listener.onQuantityChanged(item.getItemId(), item.getQuantityInCart() + 1);
        });

        holder.btnRemove.setOnClickListener(v -> listener.onItemRemoved(item.getItemId()));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivItemImage;
        TextView tvItemName, tvItemPrice, tvQuantity, tvSubtotal;
        Button btnDecrease, btnIncrease, btnRemove;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivItemImage = itemView.findViewById(R.id.ivItemImage);
            tvItemName = itemView.findViewById(R.id.tvItemName);
            tvItemPrice = itemView.findViewById(R.id.tvItemPrice);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
            tvSubtotal = itemView.findViewById(R.id.tvSubtotal);
            btnDecrease = itemView.findViewById(R.id.btnDecrease);
            btnIncrease = itemView.findViewById(R.id.btnIncrease);
            btnRemove = itemView.findViewById(R.id.btnRemove);
        }
    }
}
