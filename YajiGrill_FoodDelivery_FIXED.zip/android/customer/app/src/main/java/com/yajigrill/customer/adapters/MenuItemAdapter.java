package com.yajigrill.customer.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.yajigrill.customer.R;
import com.yajigrill.customer.models.MenuItem;
import com.yajigrill.customer.utils.Constants;
import java.util.List;

public class MenuItemAdapter extends RecyclerView.Adapter<MenuItemAdapter.ViewHolder> {

    private List<MenuItem> items;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(MenuItem item);
    }

    public MenuItemAdapter(List<MenuItem> items, OnItemClickListener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_menu, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MenuItem item = items.get(position);
        holder.tvItemName.setText(item.getItemName());
        holder.tvItemPrice.setText(Constants.formatCurrency(item.getPrice()));
        holder.tvPrepTime.setText(item.getPreparationTime() + " min");
        holder.ratingBar.setRating((float) item.getRating());

        Glide.with(holder.itemView.getContext())
            .load(item.getImageUrl())
            .placeholder(R.drawable.ic_food_placeholder)
            .into(holder.ivItemImage);

        holder.cardView.setOnClickListener(v -> listener.onItemClick(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        ImageView ivItemImage;
        TextView tvItemName, tvItemPrice, tvPrepTime;
        RatingBar ratingBar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            ivItemImage = itemView.findViewById(R.id.ivItemImage);
            tvItemName = itemView.findViewById(R.id.tvItemName);
            tvItemPrice = itemView.findViewById(R.id.tvItemPrice);
            tvPrepTime = itemView.findViewById(R.id.tvPrepTime);
            ratingBar = itemView.findViewById(R.id.ratingBar);
        }
    }
}
