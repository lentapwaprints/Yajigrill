package com.yajigrill.customer.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.yajigrill.customer.R;
import com.yajigrill.customer.network.ApiHelper;
import com.yajigrill.customer.utils.Constants;
import com.yajigrill.customer.utils.SessionManager;
import org.json.JSONException;
import org.json.JSONObject;

public class ProfileActivity extends AppCompatActivity {

    private EditText etFullName, etEmail, etPhone, etAddress;
    private Button btnUpdate, btnLogout;
    private ApiHelper apiHelper;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        apiHelper = new ApiHelper(this);
        sessionManager = new SessionManager(this);

        etFullName = findViewById(R.id.etFullName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etAddress = findViewById(R.id.etAddress);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnLogout = findViewById(R.id.btnLogout);

        // Load current data
        etFullName.setText(sessionManager.getUserName());
        etEmail.setText(sessionManager.getUserEmail());
        etPhone.setText(sessionManager.getUserPhone());
        etAddress.setText(sessionManager.getUserAddress());

        btnUpdate.setOnClickListener(v -> updateProfile());
        btnLogout.setOnClickListener(v -> {
            sessionManager.clearSession();
            Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    private void updateProfile() {
        String fullName = etFullName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String address = etAddress.getText().toString().trim();

        if (fullName.isEmpty()) { etFullName.setError("Required"); return; }
        if (phone.isEmpty()) { etPhone.setError("Required"); return; }

        try {
            JSONObject params = new JSONObject();
            params.put("full_name", fullName);
            params.put("phone", phone);
            params.put("address", address);

            apiHelper.post(Constants.API_UPDATE_PROFILE, params, new ApiHelper.ApiCallback() {
                @Override
                public void onSuccess(String response) {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getString("status").equals("success")) {
                            sessionManager.setUserData(
                                sessionManager.getUserId(), fullName,
                                sessionManager.getUserEmail(), phone, address,
                                sessionManager.getAuthToken()
                            );
                            Toast.makeText(ProfileActivity.this, "Profile updated", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onError(String error) {
                    Toast.makeText(ProfileActivity.this, "Error: " + error, Toast.LENGTH_SHORT).show();
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
