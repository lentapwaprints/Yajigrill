package com.yajigrill.customer.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.yajigrill.customer.R;
import com.yajigrill.customer.adapters.CartAdapter;
import com.yajigrill.customer.models.MenuItem;
import com.yajigrill.customer.utils.CartManager;
import com.yajigrill.customer.utils.Constants;
import java.util.List;

public class CartActivity extends AppCompatActivity {

    private RecyclerView rvCartItems;
    private TextView tvSubtotal, tvDeliveryFee, tvTotal;
    private Button btnCheckout;
    private CartManager cartManager;
    private CartAdapter cartAdapter;
    private List<MenuItem> cartItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        cartManager = new CartManager(this);
        rvCartItems = findViewById(R.id.rvCartItems);
        tvSubtotal = findViewById(R.id.tvSubtotal);
        tvDeliveryFee = findViewById(R.id.tvDeliveryFee);
        tvTotal = findViewById(R.id.tvTotal);
        btnCheckout = findViewById(R.id.btnCheckout);

        rvCartItems.setLayoutManager(new LinearLayoutManager(this));
        loadCart();

        btnCheckout.setOnClickListener(v -> {
            if (cartItems.isEmpty()) {
                Toast.makeText(this, "Your cart is empty", Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(CartActivity.this, CheckoutActivity.class));
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadCart();
    }

    private void loadCart() {
        cartItems = cartManager.getCartItems();
        cartAdapter = new CartAdapter(cartItems, new CartAdapter.CartListener() {
            @Override
            public void onQuantityChanged(int itemId, int quantity) {
                cartManager.updateQuantity(itemId, quantity);
                updateTotals();
            }

            @Override
            public void onItemRemoved(int itemId) {
                cartManager.removeFromCart(itemId);
                loadCart();
            }
        });
        rvCartItems.setAdapter(cartAdapter);
        updateTotals();
    }

    private void updateTotals() {
        double subtotal = cartManager.getCartTotal();
        double deliveryFee = cartItems.isEmpty() ? 0 : Constants.DELIVERY_FEE;
        double total = subtotal + deliveryFee;

        tvSubtotal.setText(Constants.formatCurrency(subtotal));
        tvDeliveryFee.setText(Constants.formatCurrency(deliveryFee));
        tvTotal.setText(Constants.formatCurrency(total));
    }
}
