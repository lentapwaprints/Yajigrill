package com.yajigrill.customer.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.yajigrill.customer.R;
import com.yajigrill.customer.models.Order;
import com.yajigrill.customer.utils.Constants;
import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.ViewHolder> {

    private List<Order> orders;
    private OnOrderClickListener listener;

    public interface OnOrderClickListener {
        void onOrderClick(Order order);
    }

    public OrderAdapter(List<Order> orders, OnOrderClickListener listener) {
        this.orders = orders;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Order order = orders.get(position);
        holder.tvOrderNumber.setText("Order #" + order.getOrderNumber());
        holder.tvOrderDate.setText(order.getOrderDate());
        holder.tvOrderAmount.setText(Constants.formatCurrency(order.getFinalAmount()));
        holder.tvOrderStatus.setText(order.getStatus());

        // Set status color
        int color;
        switch (order.getStatus()) {
            case Constants.STATUS_DELIVERED:
                color = android.graphics.Color.parseColor("#4CAF50");
                break;
            case Constants.STATUS_CANCELLED:
                color = android.graphics.Color.parseColor("#F44336");
                break;
            case Constants.STATUS_PENDING:
                color = android.graphics.Color.parseColor("#FF9800");
                break;
            default:
                color = android.graphics.Color.parseColor("#2196F3");
        }
        holder.tvOrderStatus.setTextColor(color);

        StringBuilder itemsText = new StringBuilder();
        if (order.getItems() != null) {
            for (int i = 0; i < Math.min(order.getItems().size(), 2); i++) {
                itemsText.append(order.getItems().get(i).getQuantity())
                    .append(" x ")
                    .append(order.getItems().get(i).getItemName())
                    .append("
");
            }
            if (order.getItems().size() > 2) {
                itemsText.append("+ ").append(order.getItems().size() - 2).append(" more items");
            }
        }
        holder.tvOrderItems.setText(itemsText.toString().trim());

        holder.cardView.setOnClickListener(v -> listener.onOrderClick(order));
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvOrderNumber, tvOrderDate, tvOrderAmount, tvOrderStatus, tvOrderItems;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            tvOrderNumber = itemView.findViewById(R.id.tvOrderNumber);
            tvOrderDate = itemView.findViewById(R.id.tvOrderDate);
            tvOrderAmount = itemView.findViewById(R.id.tvOrderAmount);
            tvOrderStatus = itemView.findViewById(R.id.tvOrderStatus);
            tvOrderItems = itemView.findViewById(R.id.tvOrderItems);
        }
    }
}
