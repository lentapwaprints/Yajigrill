package com.yajigrill.customer.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.yajigrill.customer.R;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class StatusHistoryAdapter extends RecyclerView.Adapter<StatusHistoryAdapter.ViewHolder> {

    private JSONArray history;

    public StatusHistoryAdapter(JSONArray history) {
        this.history = history;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_status_history, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            JSONObject obj = history.getJSONObject(position);
            holder.tvStatus.setText(obj.getString("status"));
            holder.tvNotes.setText(obj.getString("notes"));
            holder.tvTime.setText(obj.getString("created_at"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return history.length();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvStatus, tvNotes, tvTime;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvNotes = itemView.findViewById(R.id.tvNotes);
            tvTime = itemView.findViewById(R.id.tvTime);
        }
    }
}
