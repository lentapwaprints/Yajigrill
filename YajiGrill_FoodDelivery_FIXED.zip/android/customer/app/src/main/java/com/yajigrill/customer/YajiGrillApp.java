package com.yajigrill.customer;

import android.app.Application;
import com.google.firebase.FirebaseApp;

public class YajiGrillApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseApp.initializeApp(this);
    }
}
