package com.yajigrill.customer.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.yajigrill.customer.R;
import com.yajigrill.customer.models.MenuItem;
import com.yajigrill.customer.utils.CartManager;
import com.yajigrill.customer.utils.Constants;

public class MenuDetailActivity extends AppCompatActivity {

    private ImageView ivMenuImage;
    private TextView tvItemName, tvItemPrice, tvDescription, tvPreparationTime, tvQuantity;
    private Button btnDecrease, btnIncrease, btnAddToCart;
    private CartManager cartManager;
    private MenuItem menuItem;
    private int quantity = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_detail);

        cartManager = new CartManager(this);
        menuItem = (MenuItem) getIntent().getSerializableExtra("menu_item");

        ivMenuImage = findViewById(R.id.ivMenuImage);
        tvItemName = findViewById(R.id.tvItemName);
        tvItemPrice = findViewById(R.id.tvItemPrice);
        tvDescription = findViewById(R.id.tvDescription);
        tvPreparationTime = findViewById(R.id.tvPreparationTime);
        tvQuantity = findViewById(R.id.tvQuantity);
        btnDecrease = findViewById(R.id.btnDecrease);
        btnIncrease = findViewById(R.id.btnIncrease);
        btnAddToCart = findViewById(R.id.btnAddToCart);

        if (menuItem != null) {
            tvItemName.setText(menuItem.getItemName());
            tvItemPrice.setText(Constants.formatCurrency(menuItem.getPrice()));
            tvDescription.setText(menuItem.getDescription());
            tvPreparationTime.setText("Prep time: " + menuItem.getPreparationTime() + " mins");

            Glide.with(this)
                .load(menuItem.getImageUrl())
                .placeholder(R.drawable.ic_food_placeholder)
                .into(ivMenuImage);
        }

        btnDecrease.setOnClickListener(v -> {
            if (quantity > 1) {
                quantity--;
                tvQuantity.setText(String.valueOf(quantity));
            }
        });

        btnIncrease.setOnClickListener(v -> {
            quantity++;
            tvQuantity.setText(String.valueOf(quantity));
        });

        btnAddToCart.setOnClickListener(v -> {
            menuItem.setQuantityInCart(quantity);
            cartManager.addToCart(menuItem);
            Toast.makeText(this, quantity + " x " + menuItem.getItemName() + " added to cart", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
