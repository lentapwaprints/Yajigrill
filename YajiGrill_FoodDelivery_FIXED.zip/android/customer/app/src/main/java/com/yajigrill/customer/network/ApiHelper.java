package com.yajigrill.customer.network;

import android.content.Context;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.yajigrill.customer.utils.Constants;
import com.yajigrill.customer.utils.SessionManager;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class ApiHelper {
    private Context context;
    private SessionManager sessionManager;

    public ApiHelper(Context context) {
        this.context = context;
        this.sessionManager = new SessionManager(context);
    }

    public void get(String url, final ApiCallback callback) {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
            response -> callback.onSuccess(response),
            error -> callback.onError(error.getMessage())) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("Authorization", "Bearer " + sessionManager.getAuthToken());
                return headers;
            }
        };
        VolleySingleton.getInstance(context).addToRequestQueue(stringRequest);
    }

    public void post(String url, JSONObject params, final ApiCallback callback) {
        JsonObjectRequest jsonRequest = new JsonObjectRequest(Request.Method.POST, url, params,
            response -> callback.onSuccess(response.toString()),
            error -> callback.onError(error.getMessage())) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("Authorization", "Bearer " + sessionManager.getAuthToken());
                headers.put("Content-Type", "application/json");
                return headers;
            }
        };
        VolleySingleton.getInstance(context).addToRequestQueue(jsonRequest);
    }

    public void postWithoutAuth(String url, JSONObject params, final ApiCallback callback) {
        JsonObjectRequest jsonRequest = new JsonObjectRequest(Request.Method.POST, url, params,
            response -> callback.onSuccess(response.toString()),
            error -> callback.onError(error.getMessage()));
        VolleySingleton.getInstance(context).addToRequestQueue(jsonRequest);
    }

    public interface ApiCallback {
        void onSuccess(String response);
        void onError(String error);
    }
}
