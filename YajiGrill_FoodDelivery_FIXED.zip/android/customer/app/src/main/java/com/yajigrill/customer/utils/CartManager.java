package com.yajigrill.customer.utils;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.yajigrill.customer.models.MenuItem;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class CartManager {
    private static final String CART_PREF = "CartPrefs";
    private static final String CART_ITEMS = "cart_items";
    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    private Gson gson;

    public CartManager(Context context) {
        pref = context.getSharedPreferences(CART_PREF, Context.MODE_PRIVATE);
        editor = pref.edit();
        gson = new Gson();
    }

    public void addToCart(MenuItem item) {
        List<MenuItem> cart = getCartItems();
        boolean found = false;
        for (MenuItem cartItem : cart) {
            if (cartItem.getItemId() == item.getItemId()) {
                cartItem.setQuantityInCart(cartItem.getQuantityInCart() + item.getQuantityInCart());
                found = true;
                break;
            }
        }
        if (!found) {
            cart.add(item);
        }
        saveCart(cart);
    }

    public void updateQuantity(int itemId, int quantity) {
        List<MenuItem> cart = getCartItems();
        for (MenuItem item : cart) {
            if (item.getItemId() == itemId) {
                if (quantity <= 0) {
                    cart.remove(item);
                } else {
                    item.setQuantityInCart(quantity);
                }
                break;
            }
        }
        saveCart(cart);
    }

    public void removeFromCart(int itemId) {
        List<MenuItem> cart = getCartItems();
        cart.removeIf(item -> item.getItemId() == itemId);
        saveCart(cart);
    }

    public List<MenuItem> getCartItems() {
        String json = pref.getString(CART_ITEMS, null);
        if (json == null) return new ArrayList<>();
        Type type = new TypeToken<List<MenuItem>>(){}.getType();
        return gson.fromJson(json, type);
    }

    public void clearCart() {
        editor.remove(CART_ITEMS);
        editor.commit();
    }

    public double getCartTotal() {
        double total = 0;
        for (MenuItem item : getCartItems()) {
            total += item.getPrice() * item.getQuantityInCart();
        }
        return total;
    }

    public int getCartCount() {
        int count = 0;
        for (MenuItem item : getCartItems()) {
            count += item.getQuantityInCart();
        }
        return count;
    }

    private void saveCart(List<MenuItem> cart) {
        String json = gson.toJson(cart);
        editor.putString(CART_ITEMS, json);
        editor.commit();
    }
}
