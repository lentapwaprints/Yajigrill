package com.yajigrill.customer.utils;

import java.text.NumberFormat;
import java.util.Locale;

public class Constants {
    // API Base URL - Change to your server IP/Domain
    public static final String BASE_URL = "http://192.168.1.100/yajigrill/api/";
    public static final String IMAGE_BASE_URL = "http://192.168.1.100/yajigrill/uploads/menu_images/";

    // API Endpoints
    public static final String API_REGISTER = BASE_URL + "customer_register.php";
    public static final String API_LOGIN = BASE_URL + "customer_login.php";
    public static final String API_GET_CATEGORIES = BASE_URL + "get_categories.php";
    public static final String API_GET_MENU_ITEMS = BASE_URL + "get_menu_items.php";
    public static final String API_PLACE_ORDER = BASE_URL + "place_order.php";
    public static final String API_GET_ORDERS = BASE_URL + "get_orders.php";
    public static final String API_TRACK_ORDER = BASE_URL + "track_order.php";
    public static final String API_UPDATE_PROFILE = BASE_URL + "update_profile.php";
    public static final String API_SUBMIT_REVIEW = BASE_URL + "submit_review.php";
    public static final String API_GET_NOTIFICATIONS = BASE_URL + "get_notifications.php";

    // Shared Preferences Keys
    public static final String PREF_NAME = "YajiGrillPrefs";
    public static final String KEY_USER_ID = "user_id";
    public static final String KEY_USER_NAME = "user_name";
    public static final String KEY_USER_EMAIL = "user_email";
    public static final String KEY_USER_PHONE = "user_phone";
    public static final String KEY_USER_ADDRESS = "user_address";
    public static final String KEY_AUTH_TOKEN = "auth_token";
    public static final String KEY_FCM_TOKEN = "fcm_token";
    public static final String KEY_IS_LOGGED_IN = "is_logged_in";

    // Order Status
    public static final String STATUS_PENDING = "Pending";
    public static final String STATUS_CONFIRMED = "Confirmed";
    public static final String STATUS_PREPARING = "Preparing";
    public static final String STATUS_READY = "Ready";
    public static final String STATUS_OUT_FOR_DELIVERY = "Out for Delivery";
    public static final String STATUS_DELIVERED = "Delivered";
    public static final String STATUS_CANCELLED = "Cancelled";

    // Delivery Fee
    public static final double DELIVERY_FEE = 500.0;

    // Request Codes
    public static final int RC_LOCATION_PERMISSION = 1001;
    public static final int RC_PAYMENT = 1002;

    // Format currency in Nigerian Naira
    public static String formatCurrency(double amount) {
        NumberFormat formatter = NumberFormat.getCurrencyInstance(new Locale("en", "NG"));
        return formatter.format(amount);
    }
}
