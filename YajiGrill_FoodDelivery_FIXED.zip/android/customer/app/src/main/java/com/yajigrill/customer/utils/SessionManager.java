package com.yajigrill.customer.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    private Context context;

    public SessionManager(Context context) {
        this.context = context;
        pref = context.getSharedPreferences(Constants.PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public void setLogin(boolean isLoggedIn) {
        editor.putBoolean(Constants.KEY_IS_LOGGED_IN, isLoggedIn);
        editor.commit();
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(Constants.KEY_IS_LOGGED_IN, false);
    }

    public void setUserData(int userId, String name, String email, String phone, String address, String token) {
        editor.putInt(Constants.KEY_USER_ID, userId);
        editor.putString(Constants.KEY_USER_NAME, name);
        editor.putString(Constants.KEY_USER_EMAIL, email);
        editor.putString(Constants.KEY_USER_PHONE, phone);
        editor.putString(Constants.KEY_USER_ADDRESS, address);
        editor.putString(Constants.KEY_AUTH_TOKEN, token);
        editor.commit();
    }

    public int getUserId() {
        return pref.getInt(Constants.KEY_USER_ID, 0);
    }

    public String getUserName() {
        return pref.getString(Constants.KEY_USER_NAME, "");
    }

    public String getUserEmail() {
        return pref.getString(Constants.KEY_USER_EMAIL, "");
    }

    public String getUserPhone() {
        return pref.getString(Constants.KEY_USER_PHONE, "");
    }

    public String getUserAddress() {
        return pref.getString(Constants.KEY_USER_ADDRESS, "");
    }

    public String getAuthToken() {
        return pref.getString(Constants.KEY_AUTH_TOKEN, "");
    }

    public void setFcmToken(String token) {
        editor.putString(Constants.KEY_FCM_TOKEN, token);
        editor.commit();
    }

    public String getFcmToken() {
        return pref.getString(Constants.KEY_FCM_TOKEN, "");
    }

    public void clearSession() {
        editor.clear();
        editor.commit();
    }
}
