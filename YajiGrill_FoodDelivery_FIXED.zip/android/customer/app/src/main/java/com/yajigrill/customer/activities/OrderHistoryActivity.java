package com.yajigrill.customer.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.yajigrill.customer.R;
import com.yajigrill.customer.adapters.OrderAdapter;
import com.yajigrill.customer.models.Order;
import com.yajigrill.customer.models.OrderItem;
import com.yajigrill.customer.network.ApiHelper;
import com.yajigrill.customer.utils.Constants;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class OrderHistoryActivity extends AppCompatActivity {

    private RecyclerView rvOrders;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ApiHelper apiHelper;
    private OrderAdapter orderAdapter;
    private List<Order> orderList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        apiHelper = new ApiHelper(this);
        rvOrders = findViewById(R.id.rvOrders);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);

        rvOrders.setLayoutManager(new LinearLayoutManager(this));
        orderList = new ArrayList<>();

        orderAdapter = new OrderAdapter(orderList, order -> {
            Intent intent = new Intent(OrderHistoryActivity.this, OrderTrackingActivity.class);
            intent.putExtra("order_id", order.getOrderId());
            startActivity(intent);
        });
        rvOrders.setAdapter(orderAdapter);

        swipeRefreshLayout.setOnRefreshListener(this::loadOrders);
        loadOrders();
    }

    private void loadOrders() {
        apiHelper.get(Constants.API_GET_ORDERS, new ApiHelper.ApiCallback() {
            @Override
            public void onSuccess(String response) {
                try {
                    JSONObject json = new JSONObject(response);
                    if (json.getString("status").equals("success")) {
                        JSONArray data = json.getJSONArray("data");
                        orderList.clear();
                        for (int i = 0; i < data.length(); i++) {
                            orderList.add(parseOrder(data.getJSONObject(i)));
                        }
                        orderAdapter.notifyDataSetChanged();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                swipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onError(String error) {
                swipeRefreshLayout.setRefreshing(false);
                Toast.makeText(OrderHistoryActivity.this, "Error loading orders", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private Order parseOrder(JSONObject obj) throws JSONException {
        Order order = new Order();
        order.setOrderId(obj.getInt("order_id"));
        order.setOrderNumber(obj.getString("order_number"));
        order.setTotalAmount(obj.getDouble("total_amount"));
        order.setDeliveryFee(obj.getDouble("delivery_fee"));
        order.setFinalAmount(obj.getDouble("final_amount"));
        order.setStatus(obj.getString("status"));
        order.setPaymentStatus(obj.getString("payment_status"));
        order.setOrderDate(obj.getString("order_date"));
        order.setDeliveryPerson(obj.isNull("delivery_person") ? null : obj.getString("delivery_person"));

        JSONArray items = obj.getJSONArray("items");
        List<OrderItem> orderItems = new ArrayList<>();
        for (int j = 0; j < items.length(); j++) {
            JSONObject itemObj = items.getJSONObject(j);
            OrderItem item = new OrderItem();
            item.setItemName(itemObj.getString("item_name"));
            item.setQuantity(itemObj.getInt("quantity"));
            item.setSubtotal(itemObj.getDouble("subtotal"));
            orderItems.add(item);
        }
        order.setItems(orderItems);
        return order;
    }
}
